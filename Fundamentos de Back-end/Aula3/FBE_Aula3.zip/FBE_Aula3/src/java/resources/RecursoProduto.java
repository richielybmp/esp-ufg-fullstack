/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resources;

import com.google.gson.Gson;
import manager.AccessManager;
import dto.Produto;
import java.net.URI;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 * REST Web Service
 *
 * @author viniciusspatto
 */
@Path("produtos")
public class RecursoProduto {

    /**
     * @return a JSON (collection of produtos)
     * Acessa todos os produtos por 
     * http://localhost:8080/FBE_Aula3/resources/produtos
     */
    @GET
    @Produces("application/json" + "; charset=utf8")
    public Response getProdutos() {
        String produtos = "";
        ArrayList<Produto> prodLista = new ArrayList<Produto>();
        try {
            prodLista = new AccessManager().getProdutos();
            Gson gson = new Gson();
            produtos = gson.toJson(prodLista);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (produtos.isEmpty()) {
            return Response.status(Response.Status.NO_CONTENT).build();
        } else {
            return Response.ok(produtos).build();
        }
    }
    
    /*
     * @return a JSON (just one produto)
     *Acessa um unico o produto por 
     *http://localhost:8080/FBE_Aula3/resources/produtos/0001 (0002, ...)
    */
    @Path("{codigo}")
    @GET
    @Produces("application/json; charset=utf8")
    public Response getProduto(@PathParam("codigo") String codigo){
        String prod = "";
        Produto produto = new Produto();
        try{
            produto = new AccessManager().getProduto(codigo);
            Gson gson = new Gson();
            prod = gson.toJson(produto);
        } catch(Exception e){
            e.printStackTrace();
        }
        if(produto.getCodigo() == null || produto.getCodigo().trim().equals("")){
            return Response.status(Response.Status.NOT_FOUND).build();
        } else{
            return Response.ok(prod).build();
        }

    }

    /*
     * @return a HTTP Response (OK or Not Found)
     *Acessa e atualiza um unico o produto por 
     *http://localhost:8080/FBE_Aula3/resources/produtos/
    */
    @PUT
    @Consumes("application/json")
    public Response setProduto(String prod) {
        boolean result = false;
        Produto produto = new Produto();
        try{
            Gson gson = new Gson();
            produto = gson.fromJson(prod, Produto.class);
            result = new AccessManager().setProduto(produto);
        } catch(Exception e){
            e.printStackTrace();
        }
        if(result){
            return Response.ok().build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }    
    }
    
    /*
     * @return a HTTP Response (OK and URI, or Expectation Failed)
     * Insere um produto por 
     *http://localhost:8080/FBE_Aula3/resources/produtos/
    */
    @POST
    @Consumes("application/json")
    public Response addProduto(String prod, @Context UriInfo uriInfo) {
        boolean result = false;
        URI uri;
        Produto produto = new Produto();
        try{
            Gson gson = new Gson();
            produto = gson.fromJson(prod, Produto.class);
            result = new AccessManager().addProduto(produto);
        } catch(Exception e){
            e.printStackTrace();
        }
        if (result){
            uri = uriInfo.getAbsolutePathBuilder().path(produto.getCodigo()).build();
            return Response.created(uri).build();
        } else{
            return Response.status(Response.Status.EXPECTATION_FAILED).build();
        }
    }
    
    /*
     * @return a HTTP Response (OK, or Not Found)
     * Exclui um produto por 
     *http://localhost:8080/FBE_Aula3/resources/produtos/del/0001 (0002, ...)
    */
    @DELETE
    @Path("del/{codigo}")
    public Response delProduto(@PathParam("codigo") String codigo){
        boolean result = false;
        try{
            result = new AccessManager().delProduto(codigo);
        } catch(Exception e){
            e.printStackTrace();
        }
        if(result){
            return Response.ok().build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }
    
}
