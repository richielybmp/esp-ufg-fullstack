/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import dao.ProdutoDAO;
import dto.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author viniciusspatto
 */
public class ProdutoDAOImpl implements ProdutoDAO {

    /**
     * Metodo chamado para executar a query para recuperar todos os produtos no
     * banco de dados (tabela produtos - bd supermercado)
     *
     * @Param Connection conn
     * @return ArrayList<Produto> produtos throws SQLException
     */
    public ArrayList<Produto> getProdutos(Connection conn) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Produto> produtos = new ArrayList<Produto>();
        try {
            String  sql = "SELECT * FROM produto";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Produto produto = new Produto();
                produto.setNome(rs.getString("nome"));
                produto.setCodigo(rs.getString("codigo"));
                produto.setPreco(rs.getFloat("preco"));
                produtos.add(produto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception e) {
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return produtos;
    }

    /**
     * Metodo chamado para executar a query para recuperar um produto no banco
     * de dados (tabela produtos - bd supermercado)
     *
     * @Param Connection conn
     * @Param String codigo
     * @return Produto produto throws SQLException
     */
    public Produto getProduto(Connection conn, String codigo) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Produto produto = new Produto();
        if (codigo.equals("")) {
            throw new SQLException("Nenhum código foi informado");
        }
        try {
            String  sql = "SELECT * FROM produto WHERE codigo=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, codigo);
            rs = ps.executeQuery();
            while(rs.next()){
                produto.setNome(rs.getString("nome"));
                produto.setCodigo(rs.getString("codigo"));
                produto.setPreco(rs.getFloat("preco"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception e) {
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return produto;
    }

    /**
     * Metodo chamado para executar a query para inserir um produto no banco de
     * dados (tabela produtos - bd supermercado)
     *
     * @Param Connection conn
     * @Param Produto produto
     * @return boolean throws SQLException
     */
    public boolean addProduto(Connection conn, Produto produto) throws SQLException {
        PreparedStatement ps = null;
        if (produto.getCodigo().trim().equals("")) {
            throw new SQLException("Nenhum produto/codigo foi informado");
        }
        try {
            String  sql = "INSERT INTO produto (nome, codigo, preco) " +
                    "VALUES(?, ?, round(CAST(? AS numeric),2)) ";
            ps = conn.prepareStatement(sql);
            ps.setString(1, produto.getNome());
            ps.setString(2, produto.getCodigo());
            ps.setFloat(3, produto.getPreco());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return true;
    }

    /**
     * Metodo chamado para executar a query para atalizar um produto no banco de
     * dados (tabela produtos - bd supermercado)
     *
     * @Param Connection conn
     * @Param Produto produto
     * @return boolean throws SQLException
     */
    public boolean setProduto(Connection conn, Produto produto) throws SQLException {
        PreparedStatement ps = null;
        if (produto.getCodigo().trim().equals("")) {
            throw new SQLException("Nenhum produto/codigo foi informado");
        }
        try {
            String  sql = "UPDATE produto SET nome=?, preco="+
                    "round(CAST(" + produto.getPreco() + "AS numeric), 2 ) "+
                    "WHERE codigo=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, produto.getNome());
            ps.setString(2, produto.getCodigo());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return true;
    }

    /**
     * Metodo chamado para executar a query para excluir um produto no banco de
     * dados (tabela produtos - bd supermercado)
     *
     * @Param Connection conn
     * @Param Produto produto
     * @return boolean throws SQLException
     */
    public boolean delProduto(Connection conn, String codigo) throws SQLException {
        PreparedStatement ps = null;
        if (codigo.equals("")) {
            throw new SQLException("Nenhum código foi informado");
        }
        try {
            String  sql = "DELETE FROM produto WHERE codigo=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, codigo);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
        }
        return true;
    }

}
