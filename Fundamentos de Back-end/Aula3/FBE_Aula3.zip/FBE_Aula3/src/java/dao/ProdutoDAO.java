/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.Produto;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author viniciusspatto
 */
public interface ProdutoDAO {

    /**
     * Metodo chamado para executar a query para recuperar todos os produtos
     * no banco de dados (tabela produtos - bd supermercado)
     * @Param Connection conn
     * @return ArrayList<Produto> produtos
     * throws SQLException
    */
    public ArrayList<Produto> getProdutos(Connection conn) throws SQLException;

    /**
     * Metodo chamado para executar a query para recuperar um produto
     * no banco de dados (tabela produtos - bd supermercado)
     * @Param Connection conn
     * @Param String codigo
     * @return Produto produto
     * throws SQLException
    */
    public Produto getProduto(Connection conn, String codigo) throws SQLException;

    /**
     * Metodo chamado para executar a query para inserir um produto
     * no banco de dados (tabela produtos - bd supermercado)
     * @Param Connection conn
     * @Param Produto produto
     * @return boolean
     * throws SQLException
    */
    public boolean addProduto(Connection conn, Produto produto) throws SQLException;
    
    /**
     * Metodo chamado para executar a query para atalizar um produto
     * no banco de dados (tabela produtos - bd supermercado)
     * @Param Connection conn
     * @Param Produto produto
     * @return boolean
     * throws SQLException
    */
    public boolean setProduto(Connection conn, Produto produto) throws SQLException;

    /**
     * Metodo chamado para executar a query para excluir um produto
     * no banco de dados (tabela produtos - bd supermercado)
     * @Param Connection conn
     * @Param Produto produto
     * @return boolean
     * throws SQLException
    */
    public boolean delProduto(Connection conn, String codigo) throws SQLException;

}
