/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author viniciusspatto
 */
public class DBConn {
    
    public Connection getConnection() throws Exception{
        try{
            Class.forName("org.postgresql.Driver"); // carrega o drive e registra no JDBC
            String url = "jdbc:postgresql://localhost/supermercado"; //caminho para o BD
            String usr = "vinicius";
            String pswrd = "vinicius";
            return DriverManager.getConnection(url, usr, pswrd);
        } catch (Exception e){
            throw e;
        }
    }
    
}
