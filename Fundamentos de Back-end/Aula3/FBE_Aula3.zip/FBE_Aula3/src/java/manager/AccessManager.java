/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import dao.DBConn;
import dao.ProdutoDAO;
import dao.impl.ProdutoDAOImpl;
import dto.Produto;
import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author viniciusspatto
 */
public class AccessManager {

    public ArrayList<Produto> getProdutos() throws Exception{
        DBConn dbConn = new DBConn();
        Connection conn = dbConn.getConnection();
        ProdutoDAO produtoDAO = new ProdutoDAOImpl();
        return produtoDAO.getProdutos(conn);
    }
    
    public Produto getProduto(String codigo) throws Exception{
        DBConn dbConn = new DBConn();
        Connection conn = dbConn.getConnection();
        ProdutoDAO produtoDAO = new ProdutoDAOImpl();
        return produtoDAO.getProduto(conn, codigo) ;
    }
    
    public boolean addProduto(Produto prod) throws Exception{
        DBConn dbConn = new DBConn();
        Connection conn = dbConn.getConnection();
        ProdutoDAO produtoDAO = new ProdutoDAOImpl();
        return produtoDAO.addProduto(conn, prod);
    }
    
    public boolean setProduto(Produto prod) throws Exception{
        DBConn dbConn = new DBConn();
        Connection conn = dbConn.getConnection();
        ProdutoDAO produtoDAO = new ProdutoDAOImpl();
        return produtoDAO.setProduto(conn, prod);
    }
    
    public boolean delProduto(String codigo) throws Exception{
        DBConn dbConn = new DBConn();
        Connection conn = dbConn.getConnection();
        ProdutoDAO produtoDAO = new ProdutoDAOImpl();
        return produtoDAO.delProduto(conn, codigo);
    }

}
