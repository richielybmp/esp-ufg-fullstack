import java.util.ArrayList;
import java.util.List;

public class Disciplina {
	List<Turma> turmas;
	String nome;
	
	public Disciplina(String nome) {
		turmas = new ArrayList<Turma>();
		this.nome = nome;
	}
	
	public Disciplina() {
		turmas = new ArrayList<Turma>();
	}
	
	public Disciplina(Disciplina disciplina) {
		this.nome = disciplina.nome;
	}
	
	public void adiciona(Turma turma) {
		turmas.add(turma);
	}
	
	public boolean vazio() {
		return turmas.isEmpty();
	}
}
