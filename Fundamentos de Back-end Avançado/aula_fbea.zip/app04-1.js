const logger = require('./app04-2');

// logger.logar('Olá NodeJs. Usando módulos.')
// logger.logar2('Olá NodeJs. Usando módulos.')
logger.log("teste");