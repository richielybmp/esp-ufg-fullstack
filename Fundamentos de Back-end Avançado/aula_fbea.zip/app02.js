// escopo restrito somente á esse arquivo
// no navegador, iria para o contexto global (window)
var mensagem = "mensagem global";
console.log(mensagem);