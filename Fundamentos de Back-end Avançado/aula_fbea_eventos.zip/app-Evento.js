// modulos existentes
const fs = require('fs');
const Events = require('events');

// modulos criados
const download = require('./app-download');
const print = require('./app-ImprimaArquivo');

// emissor de eventos
const emissor = new Events();

emissor.on('iniciarDownload', (url) => {
    console.log('*****  Iniciando seu download  *****');
    download.baixar(url);
});

emissor.on('downloadFinalizado', (file) => {
    console.log();
    console.log("*****  Download finalizado *****");
    fs.readFile(file, 'utf-8', print);
});

module.exports = emissor;