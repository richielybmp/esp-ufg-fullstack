const http = require('https');
const fs = require('fs');
const emissorDeEvento = require('./app-Evento');

function download(url, callBack){
    var file = fs.createWriteStream('C:\Users\Alunoinf_2\NodeJSPortable\aula_fbea\index.txt');
    var requiest = http.get(url, (response) =>{
        response.pipe(file);
        file.on('finish', () =>{
            file.close();
            emissorDeEvento.emit('downloadFinalizado',file.path);
        })
    })
};

module.exports.baixar = download;