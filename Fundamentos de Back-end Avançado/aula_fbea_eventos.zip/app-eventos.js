const Events = require('events');

const emissorDeEvento = new Events();

var auditarOrigem =  function(transferencia){
    console.log('Listener - Auditoria origem.');
    if(transferencia.origem == '123'){
        console.log('Essa conta está bloqueada.');
    }
};

var auditarDestino =  function(transferencia){
    console.log('Listener - Auditoria destino.');
    if(transferencia.valor > 4500){
        console.log('Oferecer investimento.');
    }
};

emissorDeEvento.on('auditarTransferencia', auditarOrigem);

emissorDeEvento.on('auditarTransferencia', auditarDestino);

//...
var valor = 5000;
var contaOrigem = '123';
var contaDestino = '456';
 if(valor > 4500) {
    emissorDeEvento.emit('auditarTransferencia', {
        valor: valor, 
        origem: contaOrigem, 
        destino: contaDestino
    });
}
//...