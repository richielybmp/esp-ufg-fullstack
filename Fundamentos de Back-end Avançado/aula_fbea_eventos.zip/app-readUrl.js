const download = require('./app-download');
const emissorDeEvento = require('./app-Evento');

emissorDeEvento.emit('iniciarDownload', process.argv[2]);